import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {FeedbackserviceService} from '../service/feedbackservice.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

databases = '';
collections = 'misclassifieds';
int = '';
db = [];
cl = [];
dbData = [];
clData = [];
intents = [];
feedbackData = [];
feedbackSaveData = [];
testData = [];
 saveStatus = '';
 trainStatus = '';
 testStatus = '';
 intRemapColDisplay = true;
 loaderDisplay = false;
 emptyFeed = true;
 emptyTest = true;
 searchText = '';

  constructor(private feedService: FeedbackserviceService, private _activatedRoute: ActivatedRoute) { }

  ngOnInit() {
     this.databases = this._activatedRoute.snapshot.params['db'];
     this.getDatabases();
     if (this.databases !== '') {
     this.getCollections(this.databases);
    }
    if (this.databases !== '' && this.collections !== '' ) {
     this.getFeedbackData(this.collections, this.databases);
     }
  }
      getDatabases() {
            this.feedService.getAccuracy().subscribe(
          data => {
            this.db = data['data'];
            for ( let i = 0; i < this.db.length; i++) {
              if (this.db[i].database.trim() !== 'local' && this.db[i].database.trim() !== 'admin') {
                this.db[i].dbName = this.db[i].database.trim().replace(/_/g, ' ');
                this.dbData.push(this.db[i]);
              }
            }

           });
    }
      getCollections(value) {
        console.log(value);
        this.clData = [];
      this.feedService.getCollections(value).subscribe(
          data => {
            this.cl = data['collections'];
            if (this.cl !== []) {
            for ( let i = 0; i < this.cl.length; i++) {
              if (this.cl[i].name.trim() === 'classifieds') {
               this.clData.push({'name': 'Matched Intents', 'value' : 'classifieds'});
              } else if (this.cl[i].name.trim() === 'unclassifieds') {
               this.clData.push({'name': 'Unmatched Intents', 'value' : 'unclassifieds'});
               } else if (this.cl[i].name.trim() === 'misclassifieds') {
               this.clData.push({'name': 'Mismatched Intents', 'value' : 'misclassifieds'});
            }}}
           });
       }

      getIntents(database) {
      this.feedService.getIntents(database).subscribe(
        data => {
              this.intents = data['intents'];
        }
      );
    }

     getFeedbackData(collection, database) {
        this.emptyFeed = true;
       this.loaderDisplay = true;
       if (collection === 'classifieds') {
       this.intRemapColDisplay = false;
      } else {
         this.intRemapColDisplay = true;
      }


     this.getIntents(database);
      this.feedService.getData(collection, database).subscribe(
        data => {
            this.feedbackData = data['data'];
            if (this.feedbackData !== [] && this.feedbackData !== null) {
                      this.emptyFeed = false;
                      for (let i = 0; i < this.feedbackData.length; i++) {
                      this.feedbackData[i].ModifiedIntent = '';
              }
        }
              this.feedbackSaveData = [];
             this.loaderDisplay = false;
            }
      );
    }

 createModTable(id, modifiedIntent) {
            if (id !== '' && id !== null && modifiedIntent !== '' && modifiedIntent !== null) {
              if (this.feedbackSaveData === null || this.feedbackSaveData === [] || this.feedbackSaveData.length <= 0) {
               this.feedbackSaveData.push({'id': id, 'selected_Intent': modifiedIntent});
            } else {
                  for (let i = 0; i < this.feedbackSaveData.length; i++ ) {
               if (this.feedbackSaveData[i].id === id) {
                 this.feedbackSaveData[i] = {'id': id, 'selected_Intent': modifiedIntent};
               } else {
                      this.feedbackSaveData.push({'id': id, 'selected_Intent': modifiedIntent});
               }
              }
              }

 } else if (id !== '' && id !== null && (modifiedIntent === '' || modifiedIntent !== null)) {
    if ((this.feedbackSaveData !== null && this.feedbackSaveData !== []) || this.feedbackSaveData.length > 0 ) {
                  for (let i = 0; i < this.feedbackSaveData.length; i++ ) {
               if (this.feedbackSaveData[i].id === id) {
                 this.feedbackSaveData.splice(i, 1);
               }
              }
 }
}
}



     postSaveCall(databases, feedbackSaveData, collections) {
        this.loaderDisplay = true;
       this.feedService.saveCall(databases, feedbackSaveData, collections).subscribe(
        data => {
            if (data.data.status === 1) {
            this.saveStatus = 'Saved Successfully';
            } else {
              this.saveStatus = 'Error Occured while saving';
            }
            this.loaderDisplay = false;
        }
      );
     }

      postTrainCall(databases) {
         this.loaderDisplay = true;
       this.feedService.trainBot(databases).subscribe(
         data => {
            if (data.data.status === 1) {
                this.trainStatus = 'It may take few minutes for Watson to train. Please wait a while before you query again!';
            } else {
              this.trainStatus = 'Error Occured while training';
            }
             this.loaderDisplay = false;
        }
       );
     }

      postTestCall(databases) {
         this.loaderDisplay = true;
       this.feedService.testBot(databases).subscribe(
         data => {
           this.testData = data['validationData'];
            if (this.testData !== []) {
             this.emptyTest = false;
            }
            this.loaderDisplay = false;
        }
       );
     }

}
